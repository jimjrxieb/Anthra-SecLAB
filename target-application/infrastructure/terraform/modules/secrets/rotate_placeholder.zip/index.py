import json
def handler(event, context):
    """Placeholder for Secrets Manager rotation Lambda.
    Replace with AWS-provided rotation template for PostgreSQL:
    https://docs.aws.amazon.com/secretsmanager/latest/userguide/rotating-secrets_lambda-function-customizing.html
    """
    raise NotImplementedError("Deploy actual rotation Lambda before enabling rotation")

